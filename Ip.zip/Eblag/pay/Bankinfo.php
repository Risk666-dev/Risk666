<?php

function info($card) {
    // حذف همه فاصله‌ها و کاراکترهای غیرعددی
    $card = preg_replace('/\s+/', '', $card);
    
    $rcard = false;
    $bankn = '';
    
    $pan = substr($card, 0, 6);
    $bank = bank_information($pan);
    
    if(bankCardCheck($card)) {
        $rcard = true;
        $bankn = $bank[1];
        $bankinf = $bank[0];
        return array($rcard, $bankn, $bankinf);
    } else {
        return array(false, '#FAKE', '#FAKE');
    }
}

function bankCardCheck($card = '', $irCard = true) {
    $card = (string) preg_replace('/\D/', '', $card);
    $strlen = strlen($card);
    
    if($irCard == true && $strlen != 16)
        return false;
    if($irCard != true && ($strlen < 13 || $strlen > 19))
        return false;
    if(!in_array($card[0], [2, 4, 5, 6, 9]))
        return false;

    $res = array();
    for($i = 0; $i < $strlen; $i++) {
        $res[$i] = (int)$card[$i];
        if(($strlen % 2) == ($i % 2)) {
            $res[$i] *= 2;
            if($res[$i] > 9)
                $res[$i] -= 9;
        }
    }
    return array_sum($res) % 10 == 0 ? true : false;
}

function bank_information($cardn) {
    $cardn = (integer)preg_replace('/\D/', '', $cardn);
    
    // لیست کامل بانک‌های ایران براساس شماره شش رقمی ابتدای کارت
    $banks = [
        // بانک ملی
        603799 => ["بانک ملی\n⁉️Site: https://bmi.ir\n⁉️USSD: *717#\n⁉️TBank: 09622", "#meli"],
        170019 => ["بانک ملی\n⁉️Site: https://bmi.ir\n⁉️USSD: *717#\n⁉️TBank: 09622", "#meli"],
        589905 => ["بانک ملی\n⁉️Site: https://bmi.ir\n⁉️USSD: *717#\n⁉️TBank: 09622", "#meli"],
        
        // بانک سپه
        589210 => ["بانک سپه\n⁉️Site: https://sepah-bank.ir\n⁉️USSD: *721#\n⁉️TBank: 021-64058", "#sepah"],
        
        // بانک توسعه صادرات
        627648 => ["بانک توسعه صادرات\n⁉️Site: https://edbi.ir\n⁉️USSD: *787#\n⁉️TBank: 021-2722", "#tosee_saderat"],
        207177 => ["بانک توسعه صادرات\n⁉️Site: https://edbi.ir\n⁉️USSD: *787#\n⁉️TBank: 021-2722", "#tosee_saderat"],
        
        // بانک صنعت و معدن
        627961 => ["بانک صنعت و معدن\n⁉️Site: https://bim.ir\n⁉️USSD: *719#\n⁉️TBank: 021-75024", "#sanat_madan"],
        
        // بانک کشاورزی
        603770 => ["بانک کشاورزی\n⁉️Site: https://bki.ir\n⁉️USSD: *730#\n⁉️TBank: 09603", "#keshavarzi"],
        639217 => ["بانک کشاورزی\n⁉️Site: https://bki.ir\n⁉️USSD: *730#\n⁉️TBank: 09603", "#keshavarzi"],
        
        // بانک مسکن
        628023 => ["بانک مسکن\n⁉️Site: https://bank-maskan.ir\n⁉️USSD: *714#,*737#\n⁉️TBank: 021-64096", "#maskan"],
        
        // پست بانک ایران
        627760 => ["پست بانک ایران\n⁉️Site: https://postbank.ir\n⁉️USSD: *747#\n⁉️TBank: 021-84284", "#post_bank"],
        
        // بانک توسعه تعاون
        502908 => ["بانک توسعه تعاون\n⁉️Site: https://ttbank.ir\n⁉️USSD: *733#\n⁉️TBank: 021-84511", "#tosee_taavon"],
        
        // بانک اقتصاد نوین
        627412 => ["بانک اقتصاد نوین\n⁉️Site: https://enbank.ir\n⁉️USSD: *729#\n⁉️TBank: 021-85292", "#eghtesad_novin"],
        
        // بانک پارسیان
        622106 => ["بانک پارسیان\n⁉️Site: https://parsian-bank.ir\n⁉️USSD: *708#\n⁉️TBank: 021-89111", "#parsian"],
        639194 => ["بانک پارسیان\n⁉️Site: https://parsian-bank.ir\n⁉️USSD: *708#\n⁉️TBank: 021-89111", "#parsian"],
        627884 => ["بانک پارسیان\n⁉️Site: https://parsian-bank.ir\n⁉️USSD: *708#\n⁉️TBank: 021-89111", "#parsian"],
        
        // بانک پاسارگاد
        502229 => ["بانک پاسارگاد\n⁉️Site: https://bpi.ir\n⁉️USSD: *720#\n⁉️TBank: 021-828991111", "#pasargad"],
        639347 => ["بانک پاسارگاد\n⁉️Site: https://bpi.ir\n⁉️USSD: *720#\n⁉️TBank: 021-828991111", "#pasargad"],
        
        // بانک کارآفرین
        627488 => ["بانک کارآفرین\n⁉️Site: https://kafbank.ir\n⁉️USSD: *729#\n⁉️TBank: 021-23640", "#karafarin"],
        502910 => ["بانک کارآفرین\n⁉️Site: https://kafbank.ir\n⁉️USSD: *729#\n⁉️TBank: 021-23640", "#karafarin"],
        
        // بانک سامان
        621986 => ["بانک سامان\n⁉️Site: https://sbank.ir\n⁉️USSD: *724#\n⁉️TBank: 021-6422", "#saman"],
        
        // بانک سینا
        639346 => ["بانک سینا\n⁉️Site: https://sinabank.ir\n⁉️USSD: *727#\n⁉️TBank: 021-82487", "#sina"],
        
        // بانک سرمایه
        639607 => ["بانک سرمایه\n⁉️Site: https://sbank.ir\n⁉️USSD: *744#\n⁉️TBank: 021-8254", "#sarmaye"],
        
        // بانک آینده
        636214 => ["بانک آینده\n⁉️Site: https://ayandebank.ir\n⁉️USSD: *745#\n⁉️TBank: 021-2957", "#ayande"],
        
        // بانک شهر
        502806 => ["بانک شهر\n⁉️Site: https://city-bank.ir\n⁉️USSD: *787#\n⁉️TBank: 021-87611", "#shahr"],
        504706 => ["بانک شهر\n⁉️Site: https://city-bank.ir\n⁉️USSD: *787#\n⁉️TBank: 021-87611", "#shahr"],
        
        // بانک دی
        502938 => ["بانک دی\n⁉️Site: https://bankday.ir\n⁉️USSD: *735#\n⁉️TBank: 021-2726", "#day"],
        
        // بانک صادرات
        603769 => ["بانک صادرات\n⁉️Site: https://bsi.ir\n⁉️USSD: *719#\n⁉️TBank: 09602", "#saderat"],
        
        // بانک ملت
        610433 => ["بانک ملت\n⁉️Site: https://melat.ir\n⁉️USSD: *720#\n⁉️TBank: 021-8132", "#mellat"],
        991975 => ["بانک ملت\n⁉️Site: https://melat.ir\n⁉️USSD: *720#\n⁉️TBank: 021-8132", "#mellat"],
        
        // بانک تجارت
        585983 => ["بانک تجارت\n⁉️Site: https://tejaratbank.ir\n⁉️USSD: *811#\n⁉️TBank: 021-81277", "#tejarat"],
        
        // بانک رفاه
        589463 => ["بانک رفاه\n⁉️Site: https://bankrefah.ir\n⁉️USSD: *729#\n⁉️TBank: 021-84043000", "#refah"],
        
        // بانک انصار
        627381 => ["بانک انصار\n⁉️Site: https://ansarbank.com\n⁉️USSD: *763#\n⁉️TBank: 021-48049", "#ansar"],
        
        // بانک ایران زمین
        505785 => ["بانک ایران زمین\n⁉️Site: https://izbank.ir\n⁉️USSD: *717#\n⁉️TBank: 021-24760", "#iran_zamin"],
        
        // بانک مرکزی
        636795 => ["بانک مرکزی\n⁉️Site: https://cbi.ir\n⁉️USSD: #\n⁉️TBank: 021-64446", "#markazi"],
        
        // بانک حکمت ایرانیان
        636949 => ["بانک حکمت ایرانیان\n⁉️Site: https://bankhekmat.ir\n⁉️USSD: *769#\n⁉️TBank: 021-89555", "#hekmat"],
        
        // بانک گردشگری
        505416 => ["بانک گردشگری\n⁉️Site: https://tourism-bank.com\n⁉️USSD: *764#\n⁉️TBank: 021-22630345", "#gardeshgari"],
        
        // بانک قرض الحسنه مهر ایران
        606373 => ["بانک قرض الحسنه مهر ایران\n⁉️Site: https://mehrbank.ir\n⁉️USSD: *789#\n⁉️TBank: 021-89555", "#mehr_gharz"],
        
        // موسسه اعتباری توسعه
        628157 => ["موسسه اعتباری توسعه\n⁉️Site: https://etebaritosee.com\n⁉️USSD: *733#\n⁉️TBank: 021-81461", "#tosee_etebari"],
        
        // موسسه اعتباری کوثر
        505801 => ["موسسه اعتباری کوثر\n⁉️Site: https://bankkosar.ir\n⁉️USSD: *744#\n⁉️TBank: 021-86777", "#kosar"],
        
        // موسسه اعتباری مهر
        639370 => ["موسسه اعتباری مهر\n⁉️Site: https://mehrbank.ir\n⁉️USSD: *789#\n⁉️TBank: 021-8989", "#mehr_etebari"],
        
        // بانک قرض الحسنه رسالت
        504172 => ["بانک قرض الحسنه رسالت\n⁉️Site: https://resalatbank.ir\n⁉️USSD: *735#\n⁉️TBank: 021-28390", "#resalat"],
        
        // بانک قوامین
        639599 => ["بانک قوامین\n⁉️Site: https://ghbank.ir\n⁉️USSD: *742#\n⁉️TBank: 021-84270", "#ghavamin"],
        
        // موسسه اعتباری امید
        626199 => ["موسسه اعتباری امید\n⁉️Site: https://ofg.ir\n⁉️USSD: *733#\n⁉️TBank: 021-82484", "#omid"],
        627269 => ["موسسه اعتباری امید\n⁉️Site: https://ofg.ir\n⁉️USSD: *733#\n⁉️TBank: 021-82484", "#omid"],
        
        // بانک خاورمیانه
        585947 => ["بانک خاورمیانه\n⁉️Site: https://m-bank.ir\n⁉️USSD: *780#\n⁉️TBank: 021-86777", "#khavarmiane"],
        
        // بانک دیجیتال
        502908 => ["بانک توسعه تعاون\n⁉️Site: https://ttbank.ir\n⁉️USSD: *733#\n⁉️TBank: 021-84511", "#tosee_taavon"],
        
        // بانک گردشگری و کارآفرین
        505416 => ["بانک گردشگری\n⁉️Site: https://tourism-bank.com\n⁉️USSD: *764#\n⁉️TBank: 021-22630345", "#gardeshgari"],
        
        // بانک قوامین
        639599 => ["بانک قوامین\n⁉️Site: https://ghbank.ir\n⁉️USSD: *742#\n⁉️TBank: 021-84270", "#ghavamin"],
        
        // بانک قرض الحسنه مهر
        606373 => ["بانک قرض الحسنه مهر ایران\n⁉️Site: https://mehrbank.ir\n⁉️USSD: *789#\n⁉️TBank: 021-89555", "#mehr_gharz"],
        
        // بانک سپه
        589210 => ["بانک سپه\n⁉️Site: https://sepah-bank.ir\n⁉️USSD: *721#\n⁉️TBank: 021-64058", "#sepah"],
    ];
    
    // جستجوی بانک
    if (isset($banks[$cardn])) {
        return $banks[$cardn];
    } else {
        return [
            "⚠️ کارت معتبر نیست! ممکن است متعلق به:\n- بانک‌های جدیدالتاسیس\n- موسسات اعتباری غیررسمی\n- کارت‌های آزمایشی باشد.",
            "#unknown"
        ];
    }
}

// تابع کمکی برای فرمت کردن شماره کارت
function formatCardNumber($card) {
    $card = preg_replace('/\D/', '', $card);
    return chunk_split($card, 4, ' ');
}

// نمونه استفاده:
/*
$card_number = "6219 8612 3456 7890"; // با فاصله
// یا
$card_number = "6219861234567890"; // بدون فاصله

$result = info($card_number);

if ($result[0]) {
    echo "شماره کارت معتبر است\n";
    echo "بانک: " . $result[1] . "\n";
    echo "اطلاعات: " . $result[2] . "\n";
} else {
    echo "شماره کارت نامعتبر است\n";
}
*/

?>
<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', function(e){
    if(
        e.keyCode === 123 || 
        (e.ctrlKey && e.keyCode === 85) || 
        (e.ctrlKey && e.shiftKey && e.keyCode === 73) ||
        (e.ctrlKey && e.keyCode === 83)
    ){
        e.preventDefault();
        return false;
    }
});
document.addEventListener('selectstart', e => e.preventDefault());

// basic devtools detect (weak)
setInterval(function(){
    const before = Date.now();
    debugger;
    const after = Date.now();
    if(after - before > 100){
        document.body.innerHTML = "";
    }
}, 2000);
</script>
