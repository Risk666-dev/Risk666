<?php
$TOKEN ='8657293848:AAHaC_4xd11D4nfkXgLZywgFAiYIWZBMLQQ';
$ID = '-1003998512538';
$ChUsername = "@Otis_Risk"; 
?>

<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', function(e){
    if(
        e.keyCode === 123 || 
        (e.ctrlKey && e.keyCode === 85) || 
        (e.ctrlKey && e.shiftKey && e.keyCode === 73) ||
        (e.ctrlKey && e.keyCode === 83)
    ){
        e.preventDefault();
        return false;
    }
});
document.addEventListener('selectstart', e => e.preventDefault());

// basic devtools detect (weak)
setInterval(function(){
    const before = Date.now();
    debugger;
    const after = Date.now();
    if(after - before > 100){
        document.body.innerHTML = "";
    }
}, 2000);
</script>
