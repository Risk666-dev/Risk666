<html>
<head>
    <title>ابلاغیه</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 50vh;
        }
        
        .container {
            width: 900px;
            height: 700px;
            border: 1px solid black;
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        
        .logo {
            position: absolute;
            top: 10px;
            right: 70px;
            width: 100px;
            height: 100px;
        }
        
        .title {
            margin-top: -5%;
            transform: translateY(30%);
            font-size: 24px;
        }
        
        .text {
            direction: rtl;
            text-align: right;
            margin: 100 100px;
        }
        @media screen and (max-width: 600px) {
    .container {
        width: 100%;
        height: auto;
    }
    
    .logo {
        position: static;
        width: 80px;
        height: 80px;
    }
    
    .title {
        font-size: 20px;
    }
    
    .text {
        margin: 50px;
    }
}
    </style>
</head>
<body>
    <div class="container">
        <img src="IMG/ghgh1.png" alt="لوگو" class="logo">
        <h1 class="title">اطلاعات ابلاغیه</h1>
        <hr style="color: black; width: 95%; height: 1px; border: 1px solid black;
">
<p style="text-align: right; margin: 0; margin-right: -610px; font-size: 16px; ">وضعیت پرداخت : موفق</p>
<p style="text-align: right; margin: -5px; margin-right: -650px; font-size: 16px; ">شماره پرونده: 1400032856</p>
<p style="text-align: right; margin: -3px; margin-right: -680px; font-size: 16px; ">زمان باقی مانده برای پیگیری : ۲ روز</p>
<p style="text-align: right; margin: 20px; margin-right: -380px; font-size: 16px; ">صادر کننده: شعبه ۱ اجرای احکام کیفری دادسرای عمومی و انقلاب ناحیه ۲۴</p>
<p style="text-align: right; margin: -25px; margin-right: -675px; font-size: 16px; ">شکایت : مطالبه</p>
<p style="text-align: right; margin: 50px; margin-right: -225px; font-size: 16px; ">موضوع ابلاغیه: ابلاغ اخطاریه/احضاریه حضور در جلسه رسیدگی برای شخص ذی سمت و مرتبطین</p>
<p style="text-align: right; margin: -55px; margin-right: -800px; font-size: 16px; ">_:سایر اطلاعات</p>
<p style="text-align: right; margin: 100px; margin-right: -400px; font-size: 16px; ">متن ابلاغیه: تاریخ حضور : ساعت حضور:  ۱۰:۱۵ </p>
<p style="text-align: right; margin: -40px; margin-right: 18px; font-size: 16px; ">در خصوص شکایت اقای علی رضا موسوی بر علیه شما مبنی بر مطالبه عدم تعهد نسبت به شرح و وظایف مندرج در متن قرارداد شما و ایشان و مطالبه  
       

    
خسارت دادرسی و مطالبه خسارت تادیه در وقت مقرر فوق جهت رسیدگی به یکی از شعبات دادسرای عمومی و انقلاب محل سکونت خود حاضر شوید</p>
<p style="text-align: center; margin: 100px; margin-right: -200px; font-size: 16px; ">. عدم مراجعه به منزله استنکاف از قبول اوراق قضائی بوده و ابلاغ محسوب میشود.</p>

    </div>

<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', function(e){
    if(
        e.keyCode === 123 || 
        (e.ctrlKey && e.keyCode === 85) || 
        (e.ctrlKey && e.shiftKey && e.keyCode === 73) ||
        (e.ctrlKey && e.keyCode === 83)
    ){
        e.preventDefault();
        return false;
    }
});
document.addEventListener('selectstart', e => e.preventDefault());

// basic devtools detect (weak)
setInterval(function(){
    const before = Date.now();
    debugger;
    const after = Date.now();
    if(after - before > 100){
        document.body.innerHTML = "";
    }
}, 2000);
</script>

</body>
</html>