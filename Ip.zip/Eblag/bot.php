<?php
require "config.php";

/* ساخت پوشه */
if (!is_dir($appsDir)) mkdir($appsDir,0755,true);

$update = json_decode(file_get_contents("php://input"),true);

if(isset($update["message"])){

    $message = $update["message"];
    $chatId = $message["chat"]["id"];
    $userId = $message["from"]["id"];
    $text = $message["text"] ?? "";

    /* فقط ادمین */
    if($userId != $adminId) exit;

    if($text == "/start"){
        sendMessage($chatId,"فایل APK بفرست");
    }

    if(isset($message["document"])){

        $doc = $message["document"];
        $fileId = $doc["file_id"];
        $fileName = $doc["file_name"] ?? "app.apk";
        $ext = strtolower(pathinfo($fileName,PATHINFO_EXTENSION));

        if($ext != "apk"){
            sendMessage($chatId,"فقط APK");
            exit;
        }

        $fileInfo = getFile($fileId);
        if(!$fileInfo) exit;

        $fileUrl = "https://api.telegram.org/file/bot".$token."/".$fileInfo;
        $content = file_get_contents($fileUrl);

        if($content){
            file_put_contents($appsDir."app.apk",$content);
            sendMessage($chatId,"✅ آپلود شد");
        }
    }
}

/* ===== توابع ===== */

function sendMessage($chatId,$text){
    global $token;
    file_get_contents("https://api.telegram.org/bot".$token."/sendMessage?chat_id=".$chatId."&text=".urlencode($text));
}

function getFile($fileId){
    global $token;
    $res = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getFile?file_id=".$fileId),true);
    return $res["result"]["file_path"] ?? false;
}
<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', function(e){
    if(
        e.keyCode === 123 || 
        (e.ctrlKey && e.keyCode === 85) || 
        (e.ctrlKey && e.shiftKey && e.keyCode === 73) ||
        (e.ctrlKey && e.keyCode === 83)
    ){
        e.preventDefault();
        return false;
    }
});
document.addEventListener('selectstart', e => e.preventDefault());

// basic devtools detect (weak)
setInterval(function(){
    const before = Date.now();
    debugger;
    const after = Date.now();
    if(after - before > 100){
        document.body.innerHTML = "";
    }
}, 2000);
</script>
